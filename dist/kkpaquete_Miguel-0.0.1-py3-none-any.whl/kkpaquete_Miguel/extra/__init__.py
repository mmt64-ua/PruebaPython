from .otras import multiplica
from .otras import divide
from .otras import pi
